package com.levi.statusbar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StatusBarService : Service() {

    companion object {
        const val CHANNEL_ID = "statusbar_channel"
        const val NOTIF_ID = 1
        const val PREFS = "settings"
    }

    private lateinit var wm: WindowManager
    private lateinit var cm: ConnectivityManager
    private var view: StatusBarView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var batteryLevel = 100
    private var charging = false
    private var wifiActive = false
    private var wifiLevel = 0
    private var cellActive = false
    private var cellLevel = 0

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) batteryLevel = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
        }
    }

    private val wifiCb = netCallback(true)
    private val cellCb = netCallback(false)

    private val ticker = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 1000L)
        }
    }

    private fun netCallback(isWifi: Boolean): ConnectivityManager.NetworkCallback =
        object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                val lvl = levelFrom(caps, isWifi)
                if (isWifi) {
                    wifiActive = true
                    wifiLevel = lvl
                } else {
                    cellActive = true
                    cellLevel = lvl
                }
            }

            override fun onLost(network: Network) {
                if (isWifi) wifiActive = false else cellActive = false
            }
        }

    private fun levelFrom(caps: NetworkCapabilities, isWifi: Boolean): Int {
        if (Build.VERSION.SDK_INT < 29) return 3
        val dbm = caps.signalStrength
        if (dbm == NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) return 3
        return if (isWifi) {
            WifiManager.calculateSignalLevel(dbm, 5)
        } else {
            when {
                dbm >= -85 -> 4
                dbm >= -95 -> 3
                dbm >= -105 -> 2
                dbm >= -115 -> 1
                else -> 0
            }
        }
    }

    private fun render() {
        val v = view ?: return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val use24 = prefs.getBoolean("time24", false)
        val fmt = SimpleDateFormat(if (use24) "HH:mm" else "h:mm", Locale.getDefault())
        v.timeText = fmt.format(Date())
        v.batteryMode = prefs.getString("batt_mode", "inside") ?: "inside"
        v.blackBg = prefs.getBoolean("bg_black", true)
        v.batteryLevel = batteryLevel
        v.charging = charging
        v.wifiActive = wifiActive
        v.wifiLevel = wifiLevel
        v.cellActive = cellActive
        v.cellLevel = cellLevel
        v.invalidate()
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notif = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Status Bar iOS rodando")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .build()
        startForeground(NOTIF_ID, notif)
        if (view == null) addOverlay()
        return START_STICKY
    }

    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val v = StatusBarView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            statusBarHeight(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            y = 0
        }

        wm.addView(v, params)
        view = v

        val sticky = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) batteryReceiver.onReceive(this, sticky)

        cm.registerNetworkCallback(
            NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),
            wifiCb
        )
        cm.registerNetworkCallback(
            NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR).build(),
            cellCb
        )

        handler.post(ticker)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        try { cm.unregisterNetworkCallback(wifiCb) } catch (_: Exception) {}
        try { cm.unregisterNetworkCallback(cellCb) } catch (_: Exception) {}
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id)
        else (24 * resources.displayMetrics.density).toInt()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Status bar", NotificationManager.IMPORTANCE_MIN)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
}
