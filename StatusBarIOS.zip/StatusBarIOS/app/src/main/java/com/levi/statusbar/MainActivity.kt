package com.levi.statusbar

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(StatusBarService.PREFS, MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(24), dp(48), dp(24), dp(24))

        val title = TextView(this)
        title.text = "Status Bar iOS"
        title.textSize = 24f
        title.setTextColor(Color.WHITE)
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        root.addView(title)

        val enable = Switch(this)
        enable.text = "Ativar barra de status"
        enable.setTextColor(Color.WHITE)
        enable.isChecked = prefs.getBoolean("enabled", false)
        enable.setOnCheckedChangeListener { btn, checked ->
            if (checked && !Settings.canDrawOverlays(this@MainActivity)) {
                Toast.makeText(this@MainActivity, "Libera a sobreposição primeiro", Toast.LENGTH_LONG).show()
                openOverlaySettings()
                btn.isChecked = false
                return@setOnCheckedChangeListener
            }
            prefs.edit().putBoolean("enabled", checked).apply()
            val svc = Intent(this@MainActivity, StatusBarService::class.java)
            if (checked) startForegroundService(svc) else stopService(svc)
        }
        root.addView(enable)

        root.addView(sectionTitle("Hora"))
        root.addView(radioGroup(
            listOf("12 horas" to "12", "24 horas" to "24"),
            if (prefs.getBoolean("time24", false)) "24" else "12"
        ) { v -> prefs.edit().putBoolean("time24", v == "24").apply() })

        root.addView(sectionTitle("Porcentagem da bateria"))
        root.addView(radioGroup(
            listOf("Dentro do ícone" to "inside", "Fora do ícone" to "outside", "Não mostrar" to "none"),
            prefs.getString("batt_mode", "inside") ?: "inside"
        ) { v -> prefs.edit().putString("batt_mode", v).apply() })

        root.addView(sectionTitle("Aparência"))
        val blackBg = Switch(this)
        blackBg.text = "Fundo preto"
        blackBg.setTextColor(Color.WHITE)
        blackBg.isChecked = prefs.getBoolean("bg_black", true)
        blackBg.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("bg_black", c).apply() }
        root.addView(blackBg)

        root.addView(sectionTitle("Permissão"))
        val permBtn = Button(this)
        permBtn.text = "Dar permissão de sobreposição"
        permBtn.setOnClickListener { openOverlaySettings() }
        root.addView(permBtn)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun sectionTitle(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 13f
        tv.setTextColor(Color.GRAY)
        tv.setPadding(0, dp(28), 0, dp(8))
        return tv
    }

    private fun radioGroup(
        options: List<Pair<String, String>>,
        selected: String,
        onPick: (String) -> Unit
    ): RadioGroup {
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        for ((label, value) in options) {
            val rb = RadioButton(this)
            rb.text = label
            rb.setTextColor(Color.WHITE)
            rb.tag = value
            rb.id = View.generateViewId()
            group.addView(rb)
            if (value == selected) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { g, id ->
            val v = g.findViewById<RadioButton>(id)?.tag as? String
            if (v != null) onPick(v)
        }
        return group
    }
}
