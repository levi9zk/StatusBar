package com.levi.statusbar

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.util.TypedValue
import android.view.View

class StatusBarView(context: Context) : View(context) {

    var timeText = ""
    var batteryLevel = 100
    var charging = false
    var batteryMode = "inside"   // inside | outside | none
    var blackBg = true
    var wifiActive = false
    var wifiLevel = 0            // 0..4
    var cellActive = false
    var cellLevel = 0            // 0..4

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 15f, resources.displayMetrics)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()

    private fun dp(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

    private fun sp(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private fun baseline(cy: Float): Float =
        cy - (textPaint.ascent() + textPaint.descent()) / 2f

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (blackBg) Color.BLACK else Color.TRANSPARENT, PorterDuff.Mode.SRC)
        val cy = height / 2f

        // hora na esquerda
        textPaint.textSize = sp(15f)
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.WHITE
        canvas.drawText(timeText, dp(22f), baseline(cy), textPaint)

        // lado direito: bateria, wifi, sinal (desenhando da direita pra esquerda)
        var x = width - dp(18f)
        x = drawBattery(canvas, x, cy)
        x -= dp(7f)
        if (wifiActive) {
            x = drawWifi(canvas, x, cy)
            x -= dp(6f)
        }
        if (cellActive) {
            drawSignal(canvas, x, cy)
        }
    }

    private fun drawBattery(canvas: Canvas, right: Float, cy: Float): Float {
        val bodyW = dp(25f)
        val bodyH = dp(12f)
        val nubW = dp(2f)
        val bodyRight = right - nubW
        val bodyLeft = bodyRight - bodyW
        val top = cy - bodyH / 2f
        val bottom = cy + bodyH / 2f

        // contorno
        strokePaint.strokeWidth = dp(1f)
        strokePaint.alpha = 110
        rect.set(bodyLeft + dp(0.5f), top + dp(0.5f), bodyRight - dp(0.5f), bottom - dp(0.5f))
        canvas.drawRoundRect(rect, dp(3.5f), dp(3.5f), strokePaint)
        strokePaint.alpha = 255

        // ponta da bateria
        fillPaint.color = Color.WHITE
        fillPaint.alpha = 110
        rect.set(bodyRight + dp(0.5f), cy - dp(3f), right, cy + dp(3f))
        canvas.drawRoundRect(rect, dp(1f), dp(1f), fillPaint)
        fillPaint.alpha = 255

        // preenchimento
        val inset = dp(2f)
        val maxFill = bodyW - inset * 2
        val fillW = maxFill * batteryLevel.coerceIn(0, 100) / 100f
        fillPaint.color = if (batteryLevel <= 20 && !charging) Color.RED else Color.WHITE
        if (fillW > 0f) {
            rect.set(bodyLeft + inset, top + inset, bodyLeft + inset + fillW, bottom - inset)
            canvas.drawRoundRect(rect, dp(1.5f), dp(1.5f), fillPaint)
        }

        var newRight = bodyLeft
        when (batteryMode) {
            "inside" -> {
                textPaint.textSize = sp(9f)
                textPaint.textAlign = Paint.Align.CENTER
                val tx = bodyLeft + bodyW / 2f
                val ty = baseline(cy)
                val label = batteryLevel.toString()
                textPaint.color = Color.WHITE
                canvas.drawText(label, tx, ty, textPaint)
                // parte do número que cai em cima do preenchimento fica preta
                canvas.save()
                canvas.clipRect(bodyLeft, top, bodyLeft + inset + fillW, bottom)
                textPaint.color = Color.BLACK
                canvas.drawText(label, tx, ty, textPaint)
                canvas.restore()
            }
            "outside" -> {
                textPaint.textSize = sp(13f)
                textPaint.textAlign = Paint.Align.RIGHT
                textPaint.color = Color.WHITE
                val txt = "$batteryLevel%"
                val gap = dp(4f)
                canvas.drawText(txt, bodyLeft - gap, baseline(cy), textPaint)
                newRight = bodyLeft - gap - textPaint.measureText(txt)
            }
        }

        textPaint.textSize = sp(15f)
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.WHITE
        return newRight
    }

    private fun drawWifi(canvas: Canvas, right: Float, cy: Float): Float {
        val cx = right - dp(8f)
        val base = cy + dp(5.5f)
        strokePaint.strokeWidth = dp(2f)
        val radii = floatArrayOf(dp(4f), dp(8f), dp(12f))
        for (i in radii.indices) {
            val lit = wifiLevel >= i + 1
            strokePaint.alpha = if (lit) 255 else 90
            val r = radii[i]
            rect.set(cx - r, base - r, cx + r, base + r)
            canvas.drawArc(rect, 225f, 90f, false, strokePaint)
        }
        strokePaint.alpha = 255
        fillPaint.color = Color.WHITE
        fillPaint.alpha = 255
        canvas.drawCircle(cx, base, dp(1.6f), fillPaint)
        return right - dp(16f)
    }

    private fun drawSignal(canvas: Canvas, right: Float, cy: Float): Float {
        val barW = dp(3f)
        val gap = dp(1.8f)
        val heights = floatArrayOf(dp(4f), dp(6.5f), dp(9f), dp(11.5f))
        val total = barW * 4 + gap * 3
        var x = right - total
        val bottom = cy + dp(5.75f)
        fillPaint.color = Color.WHITE
        for (i in 0 until 4) {
            fillPaint.alpha = if (cellLevel > i) 255 else 90
            rect.set(x, bottom - heights[i], x + barW, bottom)
            canvas.drawRoundRect(rect, dp(1f), dp(1f), fillPaint)
            x += barW + gap
        }
        fillPaint.alpha = 255
        return right - total
    }
}
