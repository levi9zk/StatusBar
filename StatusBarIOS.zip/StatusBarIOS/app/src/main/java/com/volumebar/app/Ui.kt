package com.volumebar.app

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
const val DIALOG_THEME = android.R.style.Theme_DeviceDefault_Dialog_Alert

// posição de um cartão dentro de um grupo de cartões colados
const val GP_SINGLE = 0
const val GP_TOP = 1
const val GP_MID = 2
const val GP_BOTTOM = 3

/** Cores tiradas das imagens de referência. */
object Theme {
    val bg = Color.rgb(0x16, 0x15, 0x1B)
    val card = Color.rgb(0x27, 0x26, 0x2D)
    val nav = Color.rgb(0x25, 0x24, 0x2B)
    val chip = Color.rgb(0x36, 0x34, 0x3B)
    val divider = Color.rgb(0x4A, 0x49, 0x52)
    val accent = Color.rgb(0xC6, 0xC3, 0xF7)
    val onAccent = Color.rgb(0x2F, 0x2D, 0x4C)
    val text = Color.rgb(0xE6, 0xE1, 0xE9)
    val dim = Color.rgb(0xA9, 0xA6, 0xB1)
    val green = Color.rgb(0x34, 0xC7, 0x59)
    val orange = Color.rgb(0xFF, 0x9F, 0x0A)
    val red = Color.rgb(0xFF, 0x45, 0x3A)
    val purple = Color.rgb(0xBF, 0x5A, 0xF2)
    val blue = Color.rgb(0x0A, 0x84, 0xFF)
    val indigo = Color.rgb(0x5E, 0x5C, 0xE6)
    val previewTop = Color.rgb(0x3A, 0x37, 0x5E)
    val previewBottom = Color.rgb(0x22, 0x21, 0x2E)
}

/** Fonte do app (a fonte anexada, em assets/fonts). */
object Fonts {
    var tf: Typeface = Typeface.DEFAULT_BOLD

    fun load(context: Context) {
        tf = try {
            Typeface.createFromAsset(context.assets, "fonts/sf_heavy.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, radiusPx: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    return g
}

/** Fundo de cartão: cantos grandes nas pontas do grupo e pequenos no meio. */
fun Context.groupBg(color: Int, pos: Int): GradientDrawable {
    val big = dp(32).toFloat()
    val small = dp(7).toFloat()
    val top = if (pos == GP_SINGLE || pos == GP_TOP) big else small
    val bottom = if (pos == GP_SINGLE || pos == GP_BOTTOM) big else small
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadii = floatArrayOf(top, top, top, top, bottom, bottom, bottom, bottom)
    return g
}

// ================= animações =================

/** Encolhe um pouquinho ao encostar e volta com um "pulinho" ao soltar. */
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.animate().cancel()
                v.animate()
                    .scaleX(0.96f)
                    .scaleY(0.96f)
                    .setStartDelay(0)
                    .setDuration(90)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                v.animate().cancel()
                v.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setStartDelay(0)
                    .setDuration(220)
                    .setInterpolator(OvershootInterpolator(2.2f))
                    .start()
            }
        }
        false
    }
}

/** Troca o texto com um pequeno fade. */
fun TextView.swapText(s: String) {
    if (text.toString() == s) return
    animate().cancel()
    animate()
        .alpha(0f)
        .setStartDelay(0)
        .setDuration(90)
        .withEndAction {
            text = s
            animate().alpha(1f).setStartDelay(0).setDuration(170).start()
        }
        .start()
}

/** Muda a cor do ícone colorido com uma transição suave. */
fun tweenBadge(badge: FrameLayout, to: Int) {
    val from = (badge.tag as? Int) ?: to
    badge.tag = to
    val bg = badge.background as? GradientDrawable ?: return
    val a = ValueAnimator.ofArgb(from, to)
    a.duration = 280
    a.addUpdateListener { bg.setColor(it.animatedValue as Int) }
    a.start()
}

// ================= componentes =================

fun Context.label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val tv = TextView(this)
    tv.text = text
    tv.textSize = sp
    tv.setTextColor(color)
    tv.typeface = Fonts.tf
    return tv
}

fun Context.sectionTitle(text: String): TextView {
    val tv = label(text, 15f, Theme.accent, true)
    tv.setPadding(dp(6), dp(22), 0, dp(2))
    return tv
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = groupBg(Theme.card, GP_SINGLE)
    c.setPadding(dp(22), dp(16), dp(22), dp(20))
    val lp = LinearLayout.LayoutParams(MATCH, WRAP)
    lp.topMargin = dp(8)
    c.layoutParams = lp
    return c
}

fun Context.iconBadge(kind: Int, color: Int): FrameLayout {
    val f = FrameLayout(this)
    f.background = rounded(color, dp(12).toFloat())
    f.tag = color
    f.addView(
        IconView(this, kind, Color.WHITE),
        FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
    )
    return f
}

fun Context.textBadge(text: String, color: Int): FrameLayout {
    val f = FrameLayout(this)
    f.background = rounded(color, dp(12).toFloat())
    f.tag = color
    val tv = label(text, 15f, Color.WHITE, true)
    tv.gravity = Gravity.CENTER
    f.addView(tv, FrameLayout.LayoutParams(MATCH, MATCH))
    return f
}

class RowViews(
    val root: LinearLayout,
    val title: TextView,
    val subtitle: TextView?,
    val badge: FrameLayout
)

/** Linha em cartão: ícone, título, subtítulo e (seta | chave | nada) à direita. */
fun Context.buildRow(
    badge: FrameLayout,
    title: String,
    subtitle: String?,
    onClick: (() -> Unit)?,
    trailing: View?,
    pos: Int
): RowViews {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    r.gravity = Gravity.CENTER_VERTICAL
    r.background = groupBg(Theme.card, pos)
    r.setPadding(dp(20), dp(18), dp(20), dp(18))
    val lp = LinearLayout.LayoutParams(MATCH, WRAP)
    lp.topMargin = if (pos == GP_SINGLE || pos == GP_TOP) dp(8) else dp(3)
    r.layoutParams = lp

    r.addView(badge, LinearLayout.LayoutParams(dp(40), dp(40)))

    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    val titleTv = label(title, 17f, Theme.text, true)
    col.addView(titleTv)
    var subTv: TextView? = null
    if (subtitle != null) {
        val s = label(subtitle, 14f, Theme.dim)
        s.setPadding(0, dp(2), 0, 0)
        col.addView(s)
        subTv = s
    }
    val colParams = LinearLayout.LayoutParams(0, WRAP, 1f)
    colParams.leftMargin = dp(18)
    colParams.rightMargin = dp(8)
    r.addView(col, colParams)

    if (trailing != null) {
        r.addView(trailing)
    } else if (onClick != null) {
        r.addView(
            IconView(this, IconView.CHEVRON, Theme.dim),
            LinearLayout.LayoutParams(dp(20), dp(20))
        )
    }
    if (onClick != null) {
        r.isClickable = true
        r.setOnClickListener { onClick() }
        r.pressable()
    }
    return RowViews(r, titleTv, subTv, badge)
}

fun Context.row(
    badge: FrameLayout,
    title: String,
    subtitle: String?,
    onClick: (() -> Unit)?,
    trailing: View?,
    pos: Int = GP_SINGLE
): LinearLayout = buildRow(badge, title, subtitle, onClick, trailing, pos).root

fun Context.button(text: String, onClick: () -> Unit): TextView {
    val b = label(text, 16f, Theme.onAccent, true)
    b.gravity = Gravity.CENTER
    b.background = rounded(Theme.accent, dp(24).toFloat())
    val lp = LinearLayout.LayoutParams(MATCH, dp(54))
    lp.topMargin = dp(20)
    b.layoutParams = lp
    b.isClickable = true
    b.setOnClickListener { onClick() }
    b.pressable()
    return b
}

fun Context.styledSwitch(checked: Boolean, onChange: (Boolean) -> Unit): ToggleView =
    ToggleView(this, checked, onChange)

/** Seletor de opções com um indicador que desliza de uma opção pra outra. */
fun Context.segmented(
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit
): FrameLayout {
    val box = FrameLayout(this)
    box.background = rounded(Theme.chip, dp(20).toFloat())
    box.setPadding(dp(4), dp(4), dp(4), dp(4))
    val boxLp = LinearLayout.LayoutParams(MATCH, dp(52))
    boxLp.topMargin = dp(10)
    box.layoutParams = boxLp

    val indicator = View(this)
    indicator.background = rounded(Theme.accent, dp(16).toFloat())
    box.addView(indicator, FrameLayout.LayoutParams(0, MATCH))

    val rowBox = LinearLayout(this)
    rowBox.orientation = LinearLayout.HORIZONTAL
    box.addView(rowBox, FrameLayout.LayoutParams(MATCH, MATCH))

    val items = ArrayList<TextView>()
    var sel = selected
    var itemW = 0f

    fun colorize() {
        for (i in items.indices) {
            items[i].setTextColor(if (i == sel) Theme.onAccent else Theme.dim)
        }
    }

    fun moveIndicator(animate: Boolean) {
        val target = sel * itemW
        indicator.animate().cancel()
        if (animate) {
            indicator.animate()
                .translationX(target)
                .setDuration(280)
                .setInterpolator(OvershootInterpolator(0.9f))
                .start()
        } else {
            indicator.translationX = target
        }
    }

    box.addOnLayoutChangeListener { v, left, _, right, _, _, _, _, _ ->
        val inner = (right - left) - v.paddingLeft - v.paddingRight
        val w = inner.toFloat() / labels.size
        if (abs(w - itemW) > 0.5f) {
            itemW = w
            indicator.post {
                val lp = indicator.layoutParams
                lp.width = w.toInt()
                indicator.layoutParams = lp
                moveIndicator(false)
            }
        }
    }

    for (i in labels.indices) {
        val tv = label(labels[i], 13f, Theme.dim, true)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 1
        tv.layoutParams = LinearLayout.LayoutParams(0, MATCH, 1f)
        tv.isClickable = true
        tv.setOnClickListener {
            if (sel != i) {
                sel = i
                colorize()
                moveIndicator(true)
                onSelect(i)
            }
        }
        items.add(tv)
        rowBox.addView(tv)
    }
    colorize()
    return box
}

fun Context.slider(
    max: Int,
    progress: Int,
    onChange: (Int) -> Unit,
    onDone: (Int) -> Unit
): SeekBar {
    val sb = SeekBar(this)
    sb.max = max
    sb.progress = progress
    sb.progressTintList = ColorStateList.valueOf(Theme.accent)
    sb.thumbTintList = ColorStateList.valueOf(Theme.accent)
    val lp = LinearLayout.LayoutParams(MATCH, WRAP)
    lp.topMargin = dp(4)
    sb.layoutParams = lp
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            onChange(p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}

        override fun onStopTrackingTouch(s: SeekBar) {
            onDone(s.progress)
        }
    })
    return sb
}

private fun Context.swatch(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color or 0xFF000000.toInt())
    g.setStroke(dp(2), 0x55FFFFFF)
    return g
}

/** Linha "título + bolinha da cor atual"; ao tocar, abre o seletor de cor. */
fun Context.colorRow(title: String, color: Int, onPick: (Int) -> Unit): LinearLayout {
    var current = color
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    r.gravity = Gravity.CENTER_VERTICAL
    r.setPadding(0, dp(14), 0, dp(4))
    r.addView(label(title, 15f, Theme.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))

    val sw = View(this)
    sw.background = swatch(current)
    r.addView(sw, LinearLayout.LayoutParams(dp(34), dp(34)))

    r.isClickable = true
    r.setOnClickListener {
        showColorDialog(title, current) { picked ->
            current = picked
            sw.background = swatch(picked)
            onPick(picked)
        }
    }
    r.pressable()
    return r
}

private val PALETTE = intArrayOf(
    0xFFFFFFFF.toInt(), 0xFFE6E1E9.toInt(), 0xFFC6C3F7.toInt(), 0xFF5B8CFF.toInt(),
    0xFF2F2D4C.toInt(), 0xFF000000.toInt(), 0xFF8A8FA3.toInt(),
    0xFFFF5A5F.toInt(), 0xFFFFB040.toInt(), 0xFFFFE24A.toInt(), 0xFF4CD97B.toInt(),
    0xFF2EC4B6.toInt(), 0xFFFF6FB5.toInt(), 0xFFBF5AF2.toInt()
)

/** Deixa a caixa de diálogo com a cara do app (fundo, fonte e cores). */
fun Context.styleDialog(d: AlertDialog) {
    d.window?.setBackgroundDrawable(rounded(Theme.card, dp(28).toFloat()))

    val msg = d.findViewById<TextView>(android.R.id.message)
    if (msg != null) {
        msg.typeface = Fonts.tf
        msg.setTextColor(Theme.dim)
    }
    val titleId = resources.getIdentifier("alertTitle", "id", "android")
    if (titleId != 0) {
        val tt = d.findViewById<TextView>(titleId)
        if (tt != null) {
            tt.typeface = Fonts.tf
            tt.setTextColor(Theme.text)
        }
    }
    val pos = d.getButton(AlertDialog.BUTTON_POSITIVE)
    if (pos != null) {
        pos.typeface = Fonts.tf
        pos.setTextColor(Theme.accent)
    }
    val neg = d.getButton(AlertDialog.BUTTON_NEGATIVE)
    if (neg != null) {
        neg.typeface = Fonts.tf
        neg.setTextColor(Theme.dim)
    }
}

/** Seletor de cor: bolinhas prontas + controles de vermelho, verde e azul. */
fun Context.showColorDialog(title: String, initial: Int, onPick: (Int) -> Unit) {
    val opaque = 0xFF000000.toInt()
    var cur = initial or opaque
    var updating = false

    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(20), dp(16), dp(20), dp(4))

    val preview = View(this)
    preview.background = rounded(cur, dp(14).toFloat())
    col.addView(preview, LinearLayout.LayoutParams(MATCH, dp(44)))

    val bars = ArrayList<SeekBar>()

    fun setColor(c: Int, fromBars: Boolean) {
        cur = c or opaque
        preview.background = rounded(cur, dp(14).toFloat())
        if (!fromBars && bars.size == 3) {
            updating = true
            bars[0].progress = Color.red(cur)
            bars[1].progress = Color.green(cur)
            bars[2].progress = Color.blue(cur)
            updating = false
        }
    }

    // bolinhas prontas, em duas fileiras
    var rowBox: LinearLayout? = null
    for (i in PALETTE.indices) {
        if (i % 7 == 0) {
            rowBox = LinearLayout(this)
            rowBox.orientation = LinearLayout.HORIZONTAL
            rowBox.setPadding(0, dp(12), 0, 0)
            col.addView(rowBox)
        }
        val color = PALETTE[i]
        val dot = View(this)
        dot.background = swatch(color)
        dot.setOnClickListener { setColor(color, false) }
        dot.pressable()
        val lp = LinearLayout.LayoutParams(dp(34), dp(34))
        lp.rightMargin = dp(8)
        rowBox?.addView(dot, lp)
    }

    val names = arrayOf("R", "G", "B")
    val tints = intArrayOf(0xFFFF5A5F.toInt(), 0xFF4CD97B.toInt(), 0xFF5B8CFF.toInt())
    val start = intArrayOf(Color.red(cur), Color.green(cur), Color.blue(cur))

    for (i in 0 until 3) {
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.setPadding(0, dp(10), 0, 0)
        line.addView(label(names[i], 14f, Theme.dim, true), LinearLayout.LayoutParams(dp(22), WRAP))

        val sb = SeekBar(this)
        sb.max = 255
        sb.progress = start[i]
        sb.progressTintList = ColorStateList.valueOf(tints[i])
        sb.thumbTintList = ColorStateList.valueOf(tints[i])
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (updating || !fromUser || bars.size < 3) return
                setColor(Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress), true)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}

            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        bars.add(sb)
        line.addView(sb, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(line)
    }

    val dialog = AlertDialog.Builder(this, DIALOG_THEME)
        .setTitle(title)
        .setView(col)
        .setPositiveButton(I18n.t("ok")) { _, _ -> onPick(cur) }
        .setNegativeButton(I18n.t("cancel"), null)
        .show()
    styleDialog(dialog)
}
