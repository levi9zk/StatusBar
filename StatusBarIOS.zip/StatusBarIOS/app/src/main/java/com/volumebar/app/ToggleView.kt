package com.volumebar.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Chave de ligar/desligar no estilo da referência:
 * ligada = trilho lavanda com bolinha escura e um "check"; desligada = trilho escuro com contorno.
 */
class ToggleView(
    context: Context,
    checked: Boolean,
    private val onChange: (Boolean) -> Unit
) : View(context) {

    var isOn: Boolean = checked
        private set

    private val d = resources.displayMetrics.density
    private var progress = if (checked) 1f else 0f
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val evaluator = ArgbEvaluator()

    private val trackOff = 0xFF36343B.toInt()
    private val outline = 0xFF938F99.toInt()
    private val thumbOff = 0xFF938F99.toInt()

    init {
        isClickable = true
        setOnClickListener {
            setOn(!isOn, true)
            onChange(isOn)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((56f * d).toInt(), (34f * d).toInt())
    }

    fun setOn(value: Boolean, animate: Boolean) {
        isOn = value
        anim?.cancel()
        val target = if (value) 1f else 0f
        if (!animate) {
            progress = target
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(progress, target)
        a.duration = 260
        a.interpolator = DecelerateInterpolator(1.4f)
        a.addUpdateListener {
            progress = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
    }

    private fun mix(from: Int, to: Int): Int = evaluator.evaluate(progress, from, to) as Int

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        // trilho
        paint.style = Paint.Style.FILL
        paint.color = mix(trackOff, Theme.accent)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, paint)

        // contorno, some conforme liga
        if (progress < 1f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * d
            paint.color = outline
            paint.alpha = ((1f - progress) * 255f).toInt()
            rect.set(d, d, w - d, h - d)
            canvas.drawRoundRect(rect, h / 2f - d, h / 2f - d, paint)
            paint.alpha = 255
        }

        // bolinha: pequena e cinza (desligado) -> grande e escura (ligado)
        val r = (8f + 5f * progress) * d
        val cx = (h / 2f) + (w - h) * progress
        val cy = h / 2f
        paint.style = Paint.Style.FILL
        paint.color = mix(thumbOff, Theme.onAccent)
        canvas.drawCircle(cx, cy, r, paint)

        // check dentro da bolinha
        if (progress > 0.05f) {
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeJoin = Paint.Join.ROUND
            paint.strokeWidth = r * 0.16f
            paint.color = Theme.accent
            paint.alpha = (progress * 255f).toInt()
            path.reset()
            path.moveTo(cx - r * 0.36f, cy)
            path.lineTo(cx - r * 0.1f, cy + r * 0.26f)
            path.lineTo(cx + r * 0.4f, cy - r * 0.28f)
            canvas.drawPath(path, paint)
            paint.alpha = 255
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}
