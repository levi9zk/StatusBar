package com.volumebar.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator

/** Desenha a barra de status por cima da tela, usando o mesmo acesso de acessibilidade da Volume Bar. */
class StatusBarService : AccessibilityService() {

    private var wm: WindowManager? = null
    private var bar: StatusBarView? = null
    private var battery = 100
    private val handler = Handler(Looper.getMainLooper())

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) readBattery(intent)
            refresh()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 5000L)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.post { refresh() }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Fonts.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_TIME_TICK)
        }
        registerReceiver(receiver, filter)?.let { readBattery(it) }
        Prefs.of(this).registerOnSharedPreferenceChangeListener(prefListener)
        handler.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private fun readBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl >= 0 && scale > 0) battery = lvl * 100 / scale
    }

    private fun refresh() {
        val prefs = Prefs.of(this)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) {
            removeBar()
            return
        }
        if (bar == null) addBar()
        val v = bar ?: return

        v.clock24 = prefs.getBoolean(Prefs.KEY_CLOCK24, false)
        v.batteryMode = prefs.getInt(Prefs.KEY_BATT, Prefs.BATT_INSIDE)
        v.blackBg = prefs.getInt(Prefs.KEY_BG, Prefs.BG_BLACK) == Prefs.BG_BLACK
        v.dark = prefs.getBoolean(Prefs.KEY_DARK_TEXT, false)
        v.battery = battery
        v.updateTime()

        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        v.wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        v.cellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        v.invalidate()
    }

    private fun addBar() {
        val manager = wm ?: return
        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val height = if (resId > 0) resources.getDimensionPixelSize(resId)
        else (24 * resources.displayMetrics.density).toInt()

        val v = StatusBarView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP
        manager.addView(v, lp)
        bar = v

        if (Prefs.of(this).getBoolean(Prefs.KEY_ANIM, true)) {
            v.alpha = 0f
            v.translationY = -height.toFloat()
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(350)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    private fun removeBar() {
        val v = bar ?: return
        runCatching { wm?.removeView(v) }
        bar = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        runCatching { unregisterReceiver(receiver) }
        Prefs.of(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        removeBar()
        super.onDestroy()
    }
}
