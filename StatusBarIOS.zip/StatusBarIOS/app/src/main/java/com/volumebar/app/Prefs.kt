package com.volumebar.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "statusbar_prefs"

    const val KEY_ENABLED = "enabled"
    const val KEY_CLOCK24 = "clock24"
    const val KEY_BATT = "batt"           // BATT_*
    const val KEY_BG = "bg"               // BG_*
    const val KEY_DARK_TEXT = "dark_text"
    const val KEY_ANIM = "anim"

    const val BATT_HIDDEN = 0
    const val BATT_INSIDE = 1
    const val BATT_OUTSIDE = 2

    const val BG_BLACK = 0
    const val BG_CLEAR = 1

    fun of(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun putInt(context: Context, key: String, value: Int) {
        of(context).edit().putInt(key, value).apply()
    }

    fun putBool(context: Context, key: String, value: Boolean) {
        of(context).edit().putBoolean(key, value).apply()
    }

    fun resetAppearance(context: Context) {
        of(context).edit()
            .remove(KEY_CLOCK24)
            .remove(KEY_BATT)
            .remove(KEY_BG)
            .remove(KEY_DARK_TEXT)
            .remove(KEY_ANIM)
            .apply()
    }
}
