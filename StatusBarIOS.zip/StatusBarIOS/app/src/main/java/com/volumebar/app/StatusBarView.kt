package com.volumebar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Barra de status desenhada na mão: horário, sinal, wifi e bateria. */
class StatusBarView(context: Context) : View(context) {

    var clock24 = false
    var batteryMode = Prefs.BATT_INSIDE
    var dark = false
    var blackBg = true
    var battery = 100
    var wifi = false
    var cellular = true
    var gapDp = Prefs.DEF_GAP.toFloat()
    var timeText = ""

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    init {
        updateTime()
    }

    private fun px(v: Float): Float = v * d

    fun updateTime() {
        timeText = SimpleDateFormat(if (clock24) "HH:mm" else "h:mm", Locale.US).format(Date())
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (blackBg) c.drawColor(Color.BLACK)
        // texto escuro só faz sentido sem fundo preto
        val fg = if (dark && !blackBg) Color.BLACK else Color.WHITE
        val knock = if (fg == Color.WHITE) Color.BLACK else Color.WHITE
        val cy = height / 2f
        val level = battery.coerceIn(0, 100)

        // horário, no "ouvido" esquerdo
        p.reset()
        p.isAntiAlias = true
        p.typeface = Fonts.tf
        p.textSize = px(16f)
        p.color = fg
        p.textAlign = Paint.Align.CENTER
        c.drawText(timeText, width * 0.25f, cy - (p.descent() + p.ascent()) / 2f, p)

        // lado direito, desenhado da direita pra esquerda
        var x = width - px(20f)

        // bateria
        val bw = px(24f)
        val bh = px(12f)
        val nubW = px(1.6f)
        val nubH = px(4.5f)
        val bodyRight = x - nubW - px(0.6f)
        val bodyLeft = bodyRight - bw
        val top = cy - bh / 2f

        p.style = Paint.Style.STROKE
        p.strokeWidth = px(1f)
        p.color = fg
        p.alpha = 100
        r.set(bodyLeft, top, bodyRight, top + bh)
        c.drawRoundRect(r, px(3.8f), px(3.8f), p)

        p.style = Paint.Style.FILL
        p.alpha = 110
        r.set(bodyRight + px(0.6f), cy - nubH / 2f, x, cy + nubH / 2f)
        c.drawRoundRect(r, px(1f), px(1f), p)

        val inset = px(2f)
        val maxW = bw - inset * 2
        val fillW = (maxW * level / 100f).coerceAtLeast(px(2f))
        p.alpha = 255
        p.color = fg
        r.set(bodyLeft + inset, top + inset, bodyLeft + inset + fillW, top + bh - inset)
        c.drawRoundRect(r, px(1.6f), px(1.6f), p)

        // porcentagem dentro do ícone, recortada pelo preenchimento
        if (batteryMode == Prefs.BATT_INSIDE) {
            val label = level.toString()
            p.typeface = Fonts.tf
            p.textSize = px(9f)
            p.textAlign = Paint.Align.CENTER
            val tx = bodyLeft + bw / 2f
            val ty = cy - (p.descent() + p.ascent()) / 2f
            c.save()
            c.clipRect(bodyLeft + inset, top, bodyLeft + inset + fillW, top + bh)
            p.color = knock
            c.drawText(label, tx, ty, p)
            c.restore()
            c.save()
            c.clipRect(bodyLeft + inset + fillW, top, bodyRight, top + bh)
            p.color = fg
            c.drawText(label, tx, ty, p)
            c.restore()
        }

        val sep = px(gapDp)
        x = bodyLeft - sep

        // porcentagem fora do ícone
        if (batteryMode == Prefs.BATT_OUTSIDE) {
            val label = "$level%"
            p.color = fg
            p.alpha = 255
            p.typeface = Fonts.tf
            p.textSize = px(13f)
            p.textAlign = Paint.Align.RIGHT
            c.drawText(label, x, cy - (p.descent() + p.ascent()) / 2f, p)
            x -= p.measureText(label)
        }

        // wifi
        if (wifi) {
            val cx = x - px(9.5f)
            val base = cy + px(5.5f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = px(1.9f)
            p.strokeCap = Paint.Cap.BUTT
            p.color = fg
            p.alpha = 255
            for (rad in listOf(4.2f, 7.8f, 11.4f)) {
                val rr = px(rad)
                r.set(cx - rr, base - rr, cx + rr, base + rr)
                c.drawArc(r, 225f, 90f, false, p)
            }
            p.style = Paint.Style.FILL
            c.drawCircle(cx, base - px(1.2f), px(1.2f), p)
            x -= px(19f) + sep
        }

        // sinal (barrinhas crescendo)
        if (cellular) {
            val heights = listOf(4f, 6.5f, 9f, 11.5f)
            val barW = px(3f)
            val gap = px(1.8f)
            val totalW = heights.size * barW + (heights.size - 1) * gap
            var bx = x - totalW
            val bottom = cy + px(5.5f)
            p.style = Paint.Style.FILL
            p.color = fg
            p.alpha = 255
            for (hh in heights) {
                val h = px(hh)
                r.set(bx, bottom - h, bx + barW, bottom)
                c.drawRoundRect(r, px(1f), px(1f), p)
                bx += barW + gap
            }
        }
    }
}
