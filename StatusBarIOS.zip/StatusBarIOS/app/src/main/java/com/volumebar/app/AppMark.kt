package com.volumebar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/** Ícone do app: uma mini barra de status (sinal, wifi e bateria) num cartão com gradiente. */
class AppMarkView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(0xFF4B4680.toInt(), 0xFF16151B.toInt()),
            null,
            Shader.TileMode.CLAMP
        )
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, w * 0.28f, w * 0.28f, paint)
        paint.shader = null
        paint.color = Color.WHITE

        val cy = h * 0.5f

        // sinal: quatro barrinhas crescendo
        val barW = w * 0.075f
        val gap = w * 0.04f
        val heights = floatArrayOf(0.14f, 0.2f, 0.27f, 0.34f)
        var bx = w * 0.16f
        val bottom = cy + h * 0.17f
        for (hh in heights) {
            rect.set(bx, bottom - h * hh, bx + barW, bottom)
            canvas.drawRoundRect(rect, barW * 0.3f, barW * 0.3f, paint)
            bx += barW + gap
        }

        // wifi: arcos finos com um pontinho
        val wcx = w * 0.5f
        val wbase = cy + h * 0.17f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w * 0.035f
        paint.strokeCap = Paint.Cap.BUTT
        for (f in floatArrayOf(0.1f, 0.19f, 0.28f)) {
            val rr = w * f
            rect.set(wcx - rr, wbase - rr, wcx + rr, wbase + rr)
            canvas.drawArc(rect, 225f, 90f, false, paint)
        }
        paint.style = Paint.Style.FILL
        canvas.drawCircle(wcx, wbase - w * 0.04f, w * 0.03f, paint)

        // bateria: contorno + preenchimento
        val bw = w * 0.22f
        val bh = h * 0.2f
        val bRight = w * 0.84f
        val bLeft = bRight - bw
        val bTop = cy - bh / 2f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w * 0.02f
        rect.set(bLeft, bTop, bRight, bTop + bh)
        canvas.drawRoundRect(rect, bh * 0.35f, bh * 0.35f, paint)
        paint.style = Paint.Style.FILL
        rect.set(bRight + w * 0.015f, cy - bh * 0.18f, bRight + w * 0.04f, cy + bh * 0.18f)
        canvas.drawRoundRect(rect, w * 0.01f, w * 0.01f, paint)
        val inset = w * 0.035f
        rect.set(bLeft + inset, bTop + inset, bRight - inset - (bw - inset * 2) * 0.3f, bTop + bh - inset)
        canvas.drawRoundRect(rect, bh * 0.2f, bh * 0.2f, paint)
    }
}
