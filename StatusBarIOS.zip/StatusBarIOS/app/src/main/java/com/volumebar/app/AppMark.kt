package com.volumebar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

class AppMarkView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        paint.style = Paint.Style.FILL
        paint.color = Theme.accent
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, w * 0.28f, w * 0.28f, paint)

        val bw = w * 0.2f
        val bh = h * 0.56f
        val bx = (w - bw) / 2f
        val by = (h - bh) / 2f

        rect.set(bx, by, bx + bw, by + bh)
        paint.color = Theme.onAccent
        canvas.drawRoundRect(rect, bw / 2f, bw / 2f, paint)

        clip.reset()
        clip.addRoundRect(rect, bw / 2f, bw / 2f, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawRect(bx, by + bh * 0.4f, bx + bw, by + bh, paint)
        canvas.restore()
    }
}
