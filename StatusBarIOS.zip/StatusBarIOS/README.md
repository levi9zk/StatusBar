# Status Bar iOS

Push this folder to a GitHub repo. The workflow in .github/workflows/build.yml builds the APK.
Grab app-debug.apk from the run's Artifacts (Actions tab), install it, then open the app,
grant "Sobreposição de tela" permission, and turn on the switch.
